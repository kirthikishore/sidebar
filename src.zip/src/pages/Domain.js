import React from 'react';

function Domain() {
    return (
        <div className='domain'>
            <h1>Domain</h1>
        </div>
    );
}

export default Domain;