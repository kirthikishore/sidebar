import React from 'react';

function Booking() {
    return (
        <div className='booking'>
            <h1>Booking</h1>
        </div>
    );
}

export default Booking;