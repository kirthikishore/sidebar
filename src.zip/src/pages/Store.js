import React from 'react';

function Store() {
    return (
        <div className='store'>
            <h1>Store</h1>
        </div>
    );
}

export default Store;