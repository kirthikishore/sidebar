import React from 'react';

function Email() {
    return (
        <div className='email'>
            <h1>Email</h1>
        </div>
    );
}

export default Email;